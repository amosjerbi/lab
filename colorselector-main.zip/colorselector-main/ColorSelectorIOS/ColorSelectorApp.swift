import SwiftUI

@main
struct ColorSelectorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
} 