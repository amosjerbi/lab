import SwiftUI
import Foundation

class ColorModel: ObservableObject {
    @Published var selectedColor: Color = .red
    @Published var colorHistory: [ColorInfo] = []
    
    struct ColorInfo: Identifiable, Equatable {
        let id = UUID()
        let color: Color
        let name: String
        let hex: String
        let rgb: RGB
        let hsl: HSL
        let timestamp: Date
        
        struct RGB {
            let red: Int
            let green: Int
            let blue: Int
        }
        
        struct HSL {
            let hue: Double
            let saturation: Double
            let lightness: Double
        }
    }
    
    func addColorToHistory(_ color: Color) {
        let colorInfo = createColorInfo(from: color)
        colorHistory.insert(colorInfo, at: 0)
        
        // Keep only the last 50 colors
        if colorHistory.count > 50 {
            colorHistory = Array(colorHistory.prefix(50))
        }
    }
    
    func createColorInfo(from color: Color) -> ColorInfo {
        let uiColor = UIColor(color)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        
        uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        let rgb = ColorInfo.RGB(
            red: Int(red * 255),
            green: Int(green * 255),
            blue: Int(blue * 255)
        )
        
        let hex = String(format: "#%02X%02X%02X", rgb.red, rgb.green, rgb.blue)
        
        // Convert to HSL
        let hsl = rgbToHSL(rgb: rgb)
        
        let name = getColorName(for: rgb)
        
        return ColorInfo(
            color: color,
            name: name,
            hex: hex,
            rgb: rgb,
            hsl: hsl,
            timestamp: Date()
        )
    }
    
    private func rgbToHSL(rgb: ColorInfo.RGB) -> ColorInfo.HSL {
        let r = Double(rgb.red) / 255.0
        let g = Double(rgb.green) / 255.0
        let b = Double(rgb.blue) / 255.0
        
        let max = Swift.max(r, g, b)
        let min = Swift.min(r, g, b)
        let diff = max - min
        
        var h: Double = 0
        let s: Double
        let l: Double = (max + min) / 2
        
        if diff == 0 {
            s = 0
        } else {
            s = l > 0.5 ? diff / (2 - max - min) : diff / (max + min)
            
            switch max {
            case r:
                h = (g - b) / diff + (g < b ? 6 : 0)
            case g:
                h = (b - r) / diff + 2
            case b:
                h = (r - g) / diff + 4
            default:
                break
            }
            h /= 6
        }
        
        return ColorInfo.HSL(
            hue: h * 360,
            saturation: s * 100,
            lightness: l * 100
        )
    }
    
    private func getColorName(for rgb: ColorInfo.RGB) -> String {
        // Simple color name detection based on RGB values
        let total = rgb.red + rgb.green + rgb.blue
        
        if total < 50 {
            return "Black"
        } else if total > 700 {
            return "White"
        } else if rgb.red > rgb.green && rgb.red > rgb.blue {
            if rgb.green > 100 {
                return "Orange"
            } else {
                return "Red"
            }
        } else if rgb.green > rgb.red && rgb.green > rgb.blue {
            return "Green"
        } else if rgb.blue > rgb.red && rgb.blue > rgb.green {
            return "Blue"
        } else if rgb.red > 150 && rgb.green > 150 && rgb.blue < 100 {
            return "Yellow"
        } else if rgb.red > 150 && rgb.blue > 150 && rgb.green < 100 {
            return "Magenta"
        } else if rgb.green > 150 && rgb.blue > 150 && rgb.red < 100 {
            return "Cyan"
        } else {
            return "Gray"
        }
    }
} 