import SwiftUI

struct ColorHistoryView: View {
    @ObservedObject var colorModel: ColorModel
    
    var body: some View {
        NavigationView {
            VStack {
                if colorModel.colorHistory.isEmpty {
                    Spacer()
                    VStack(spacing: 20) {
                        Image(systemName: "paintpalette")
                            .font(.system(size: 60))
                            .foregroundColor(.gray)
                        
                        Text("No Colors Yet")
                            .font(.title2)
                            .fontWeight(.medium)
                        
                        Text("Colors you save will appear here")
                            .font(.body)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    Spacer()
                } else {
                    List {
                        ForEach(colorModel.colorHistory) { colorInfo in
                            ColorHistoryRow(colorInfo: colorInfo)
                        }
                        .onDelete(perform: deleteColors)
                    }
                }
            }
            .navigationTitle("Color History")
            .toolbar {
                if !colorModel.colorHistory.isEmpty {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Clear All") {
                            colorModel.colorHistory.removeAll()
                        }
                        .foregroundColor(.red)
                    }
                }
            }
        }
    }
    
    private func deleteColors(offsets: IndexSet) {
        colorModel.colorHistory.remove(atOffsets: offsets)
    }
}

struct ColorHistoryRow: View {
    let colorInfo: ColorModel.ColorInfo
    @State private var showingDetails = false
    
    var body: some View {
        HStack(spacing: 15) {
            // Color Preview
            RoundedRectangle(cornerRadius: 8)
                .fill(colorInfo.color)
                .frame(width: 50, height: 50)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                )
            
            // Color Info
            VStack(alignment: .leading, spacing: 4) {
                Text(colorInfo.name)
                    .font(.headline)
                
                Text(colorInfo.hex)
                    .font(.body.monospaced())
                    .foregroundColor(.secondary)
                
                Text(formatDate(colorInfo.timestamp))
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Action Buttons
            HStack(spacing: 10) {
                Button(action: {
                    UIPasteboard.general.string = colorInfo.hex
                }) {
                    Image(systemName: "doc.on.doc")
                        .foregroundColor(.blue)
                }
                
                Button(action: {
                    showingDetails.toggle()
                }) {
                    Image(systemName: "info.circle")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(.vertical, 4)
        .sheet(isPresented: $showingDetails) {
            ColorDetailView(colorInfo: colorInfo)
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

struct ColorDetailView: View {
    let colorInfo: ColorModel.ColorInfo
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // Large Color Display
                RoundedRectangle(cornerRadius: 20)
                    .fill(colorInfo.color)
                    .frame(height: 200)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                
                // Detailed Information
                VStack(spacing: 15) {
                    InfoRow(title: "Name", value: colorInfo.name)
                    InfoRow(title: "Hex", value: colorInfo.hex)
                    InfoRow(title: "RGB", value: "rgb(\(colorInfo.rgb.red), \(colorInfo.rgb.green), \(colorInfo.rgb.blue))")
                    InfoRow(title: "HSL", value: "hsl(\(Int(colorInfo.hsl.hue)), \(Int(colorInfo.hsl.saturation))%, \(Int(colorInfo.hsl.lightness))%)")
                    InfoRow(title: "Saved", value: formatDetailDate(colorInfo.timestamp))
                }
                .padding()
                
                Spacer()
                
                // Copy Actions
                VStack(spacing: 10) {
                    Button(action: {
                        UIPasteboard.general.string = colorInfo.hex
                    }) {
                        HStack {
                            Image(systemName: "doc.on.doc")
                            Text("Copy Hex")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: {
                        UIPasteboard.general.string = "rgb(\(colorInfo.rgb.red), \(colorInfo.rgb.green), \(colorInfo.rgb.blue))"
                    }) {
                        HStack {
                            Image(systemName: "doc.on.doc")
                            Text("Copy RGB")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                }
                .padding(.horizontal)
            }
            .padding()
            .navigationTitle("Color Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func formatDetailDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        formatter.timeStyle = .medium
        return formatter.string(from: date)
    }
}

struct InfoRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title + ":")
                .font(.headline)
                .frame(width: 60, alignment: .leading)
            
            Text(value)
                .font(.body.monospaced())
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.horizontal)
    }
}

#Preview {
    ColorHistoryView(colorModel: ColorModel())
} 