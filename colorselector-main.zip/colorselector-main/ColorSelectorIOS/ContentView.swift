import SwiftUI

struct ContentView: View {
    @StateObject private var colorModel = ColorModel()
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            ColorPickerView(colorModel: colorModel)
                .tabItem {
                    Image(systemName: "paintpalette")
                    Text("Color Picker")
                }
                .tag(0)
            
            ColorHistoryView(colorModel: colorModel)
                .tabItem {
                    Image(systemName: "clock")
                    Text("History")
                }
                .tag(1)
            
            ColorConverterView(colorModel: colorModel)
                .tabItem {
                    Image(systemName: "arrow.2.squarepath")
                    Text("Converter")
                }
                .tag(2)
        }
    }
}

#Preview {
    ContentView()
} 