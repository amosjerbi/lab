import SwiftUI

struct ColorPickerView: View {
    @ObservedObject var colorModel: ColorModel
    @State private var selectedColor: Color = .red
    @State private var showingColorWheel = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // Color Display
                RoundedRectangle(cornerRadius: 20)
                    .fill(selectedColor)
                    .frame(height: 200)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                    .shadow(radius: 5)
                
                // Color Information
                VStack(alignment: .leading, spacing: 8) {
                    let colorInfo = colorModel.createColorInfo(from: selectedColor)
                    
                    HStack {
                        Text("Color Name:")
                            .font(.headline)
                        Spacer()
                        Text(colorInfo.name)
                            .font(.body)
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("Hex:")
                            .font(.headline)
                        Spacer()
                        Text(colorInfo.hex)
                            .font(.body.monospaced())
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("RGB:")
                            .font(.headline)
                        Spacer()
                        Text("\(colorInfo.rgb.red), \(colorInfo.rgb.green), \(colorInfo.rgb.blue)")
                            .font(.body.monospaced())
                            .foregroundColor(.secondary)
                    }
                    
                    HStack {
                        Text("HSL:")
                            .font(.headline)
                        Spacer()
                        Text("\(Int(colorInfo.hsl.hue))°, \(Int(colorInfo.hsl.saturation))%, \(Int(colorInfo.hsl.lightness))%")
                            .font(.body.monospaced())
                            .foregroundColor(.secondary)
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(12)
                
                // Color Picker Controls
                VStack(spacing: 15) {
                    ColorPicker("Select Color", selection: $selectedColor)
                        .labelsHidden()
                    
                    // Preset Colors
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 10) {
                        ForEach(presetColors, id: \.self) { color in
                            Circle()
                                .fill(color)
                                .frame(width: 40, height: 40)
                                .overlay(
                                    Circle()
                                        .stroke(selectedColor == color ? Color.primary : Color.clear, lineWidth: 3)
                                )
                                .onTapGesture {
                                    selectedColor = color
                                }
                        }
                    }
                }
                .padding()
                
                Spacer()
                
                // Save Button
                Button(action: {
                    colorModel.selectedColor = selectedColor
                    colorModel.addColorToHistory(selectedColor)
                }) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("Save to History")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(selectedColor)
                    .cornerRadius(12)
                }
            }
            .padding()
            .navigationTitle("Color Picker")
        }
    }
    
    private var presetColors: [Color] = [
        .red, .orange, .yellow, .green, .blue, .purple,
        .pink, .cyan, .mint, .indigo, .teal, .brown,
        .black, .gray, .white, Color(red: 0.5, green: 0.5, blue: 0.5),
        Color(red: 0.2, green: 0.2, blue: 0.8), Color(red: 0.8, green: 0.2, blue: 0.2)
    ]
}

#Preview {
    ColorPickerView(colorModel: ColorModel())
} 