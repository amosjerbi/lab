import SwiftUI

struct ColorConverterView: View {
    @ObservedObject var colorModel: ColorModel
    @State private var hexInput = ""
    @State private var rgbRed = 0.0
    @State private var rgbGreen = 0.0
    @State private var rgbBlue = 0.0
    @State private var hslHue = 0.0
    @State private var hslSaturation = 50.0
    @State private var hslLightness = 50.0
    @State private var convertedColor: Color = .red
    @State private var showingAlert = false
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 25) {
                    // Color Preview
                    RoundedRectangle(cornerRadius: 20)
                        .fill(convertedColor)
                        .frame(height: 150)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                        )
                        .shadow(radius: 5)
                    
                    // Hex Input Section
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Hex Color")
                            .font(.headline)
                        
                        HStack {
                            TextField("Enter hex color (e.g., #FF5733)", text: $hexInput)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .autocapitalization(.allCharacters)
                                .onChange(of: hexInput) { _, newValue in
                                    convertFromHex(newValue)
                                }
                            
                            Button("Convert") {
                                convertFromHex(hexInput)
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(12)
                    
                    // RGB Input Section
                    VStack(alignment: .leading, spacing: 15) {
                        Text("RGB Values")
                            .font(.headline)
                        
                        VStack(spacing: 10) {
                            SliderRow(title: "Red", value: $rgbRed, range: 0...255) {
                                convertFromRGB()
                            }
                            SliderRow(title: "Green", value: $rgbGreen, range: 0...255) {
                                convertFromRGB()
                            }
                            SliderRow(title: "Blue", value: $rgbBlue, range: 0...255) {
                                convertFromRGB()
                            }
                        }
                    }
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(12)
                    
                    // HSL Input Section
                    VStack(alignment: .leading, spacing: 15) {
                        Text("HSL Values")
                            .font(.headline)
                        
                        VStack(spacing: 10) {
                            SliderRow(title: "Hue", value: $hslHue, range: 0...360, unit: "°") {
                                convertFromHSL()
                            }
                            SliderRow(title: "Saturation", value: $hslSaturation, range: 0...100, unit: "%") {
                                convertFromHSL()
                            }
                            SliderRow(title: "Lightness", value: $hslLightness, range: 0...100, unit: "%") {
                                convertFromHSL()
                            }
                        }
                    }
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(12)
                    
                    // Output Section
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Converted Values")
                            .font(.headline)
                        
                        let colorInfo = colorModel.createColorInfo(from: convertedColor)
                        
                        OutputRow(title: "Hex", value: colorInfo.hex)
                        OutputRow(title: "RGB", value: "rgb(\(colorInfo.rgb.red), \(colorInfo.rgb.green), \(colorInfo.rgb.blue))")
                        OutputRow(title: "HSL", value: "hsl(\(Int(colorInfo.hsl.hue)), \(Int(colorInfo.hsl.saturation))%, \(Int(colorInfo.hsl.lightness))%)")
                        OutputRow(title: "Color Name", value: colorInfo.name)
                    }
                    .padding()
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(12)
                    
                    // Save Button
                    Button(action: {
                        colorModel.selectedColor = convertedColor
                        colorModel.addColorToHistory(convertedColor)
                        showingAlert = true
                        alertMessage = "Color saved to history!"
                    }) {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("Save Color")
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(convertedColor)
                        .cornerRadius(12)
                    }
                }
                .padding()
            }
            .navigationTitle("Color Converter")
            .alert("Success", isPresented: $showingAlert) {
                Button("OK") { }
            } message: {
                Text(alertMessage)
            }
        }
        .onAppear {
            // Initialize with a default color
            updateInputsFromColor(.red)
        }
    }
    
    private func convertFromHex(_ hex: String) {
        let cleanedHex = hex.replacingOccurrences(of: "#", with: "")
        
        guard cleanedHex.count == 6,
              let hexValue = Int(cleanedHex, radix: 16) else {
            return
        }
        
        let red = Double((hexValue >> 16) & 0xFF)
        let green = Double((hexValue >> 8) & 0xFF)
        let blue = Double(hexValue & 0xFF)
        
        rgbRed = red
        rgbGreen = green
        rgbBlue = blue
        
        convertedColor = Color(red: red / 255.0, green: green / 255.0, blue: blue / 255.0)
        updateHSLFromRGB()
    }
    
    private func convertFromRGB() {
        convertedColor = Color(red: rgbRed / 255.0, green: rgbGreen / 255.0, blue: rgbBlue / 255.0)
        
        // Update hex
        let hexValue = String(format: "#%02X%02X%02X", Int(rgbRed), Int(rgbGreen), Int(rgbBlue))
        hexInput = hexValue
        
        updateHSLFromRGB()
    }
    
    private func convertFromHSL() {
        let rgb = hslToRGB(h: hslHue / 360.0, s: hslSaturation / 100.0, l: hslLightness / 100.0)
        
        rgbRed = Double(rgb.0)
        rgbGreen = Double(rgb.1)
        rgbBlue = Double(rgb.2)
        
        convertedColor = Color(red: Double(rgb.0) / 255.0, green: Double(rgb.1) / 255.0, blue: Double(rgb.2) / 255.0)
        
        // Update hex
        let hexValue = String(format: "#%02X%02X%02X", rgb.0, rgb.1, rgb.2)
        hexInput = hexValue
    }
    
    private func updateHSLFromRGB() {
        let r = rgbRed / 255.0
        let g = rgbGreen / 255.0
        let b = rgbBlue / 255.0
        
        let max = Swift.max(r, g, b)
        let min = Swift.min(r, g, b)
        let diff = max - min
        
        var h: Double = 0
        let s: Double
        let l: Double = (max + min) / 2
        
        if diff == 0 {
            s = 0
        } else {
            s = l > 0.5 ? diff / (2 - max - min) : diff / (max + min)
            
            switch max {
            case r:
                h = (g - b) / diff + (g < b ? 6 : 0)
            case g:
                h = (b - r) / diff + 2
            case b:
                h = (r - g) / diff + 4
            default:
                break
            }
            h /= 6
        }
        
        hslHue = h * 360
        hslSaturation = s * 100
        hslLightness = l * 100
    }
    
    private func hslToRGB(h: Double, s: Double, l: Double) -> (Int, Int, Int) {
        let c = (1 - abs(2 * l - 1)) * s
        let x = c * (1 - abs((h * 6).truncatingRemainder(dividingBy: 2) - 1))
        let m = l - c / 2
        
        var r: Double = 0
        var g: Double = 0
        var b: Double = 0
        
        let hue = h * 6
        
        if hue < 1 {
            r = c; g = x; b = 0
        } else if hue < 2 {
            r = x; g = c; b = 0
        } else if hue < 3 {
            r = 0; g = c; b = x
        } else if hue < 4 {
            r = 0; g = x; b = c
        } else if hue < 5 {
            r = x; g = 0; b = c
        } else {
            r = c; g = 0; b = x
        }
        
        return (Int((r + m) * 255), Int((g + m) * 255), Int((b + m) * 255))
    }
    
    private func updateInputsFromColor(_ color: Color) {
        let colorInfo = colorModel.createColorInfo(from: color)
        
        hexInput = colorInfo.hex
        rgbRed = Double(colorInfo.rgb.red)
        rgbGreen = Double(colorInfo.rgb.green)
        rgbBlue = Double(colorInfo.rgb.blue)
        hslHue = colorInfo.hsl.hue
        hslSaturation = colorInfo.hsl.saturation
        hslLightness = colorInfo.hsl.lightness
        
        convertedColor = color
    }
}

struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String
    let onChange: () -> Void
    
    init(title: String, value: Binding<Double>, range: ClosedRange<Double>, unit: String = "", onChange: @escaping () -> Void) {
        self.title = title
        self._value = value
        self.range = range
        self.unit = unit
        self.onChange = onChange
    }
    
    var body: some View {
        HStack {
            Text(title)
                .frame(width: 80, alignment: .leading)
            
            Slider(value: $value, in: range) { _ in
                onChange()
            }
            
            Text("\(Int(value))\(unit)")
                .frame(width: 50, alignment: .trailing)
                .font(.body.monospaced())
        }
    }
}

struct OutputRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title + ":")
                .font(.headline)
                .frame(width: 100, alignment: .leading)
            
            Text(value)
                .font(.body.monospaced())
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            Button(action: {
                UIPasteboard.general.string = value
            }) {
                Image(systemName: "doc.on.doc")
                    .foregroundColor(.blue)
            }
        }
    }
}

#Preview {
    ColorConverterView(colorModel: ColorModel())
} 