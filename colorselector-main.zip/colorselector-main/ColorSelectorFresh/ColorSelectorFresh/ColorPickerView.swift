import SwiftUI

enum ColorMode: String, CaseIterable {
    case rgb = "RGB"
    case hsb = "HSB" 
    case lab = "LAB"
}

enum ColorChannel: Int, CaseIterable {
    // RGB channels
    case red = 0, green = 1, blue = 2
    // HSB channels  
    case hue = 3, saturation = 4, brightness = 5
    // LAB channels
    case lightness = 6, aValue = 7, bValue = 8
    
    var displayName: String {
        switch self {
        case .red: return "R"
        case .green: return "G"
        case .blue: return "B"
        case .hue: return "H"
        case .saturation: return "S"
        case .brightness: return "B"
        case .lightness: return "L"
        case .aValue: return "a"
        case .bValue: return "b"
        }
    }
    
    var mode: ColorMode {
        switch self {
        case .red, .green, .blue: return .rgb
        case .hue, .saturation, .brightness: return .hsb
        case .lightness, .aValue, .bValue: return .lab
        }
    }
}

struct ColorPickerView: View {
    @ObservedObject var colorModel: ColorModel
    @State private var selectedChannel: ColorChannel = .hue
    @State private var rgbValues = (r: 255.0, g: 0.0, b: 0.0)
    @State private var hsbValues = (h: 0.0, s: 1.0, b: 1.0)
    @State private var labValues = (l: 50.0, a: 0.0, b: 0.0)
        @State private var showingAlert = false
    @State private var alertMessage = ""
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    
    var currentMode: ColorMode {
        selectedChannel.mode
    }
    
    var isRegularLayout: Bool {
        horizontalSizeClass == .regular && verticalSizeClass == .regular
    }
    
    var isLandscapeLayout: Bool {
        horizontalSizeClass == .regular && verticalSizeClass == .compact
    }
    
    var isFullyExpandedLayout: Bool {
        isRegularLayout || isLandscapeLayout
    }
    
    var body: some View {
        ScrollView {
            if isLandscapeLayout {
                landscapeLayout
            } else if isRegularLayout {
                iPadLayout
            } else {
                iPhoneLayout
            }
        }
        .navigationTitle("Color Picker")
        .navigationBarTitleDisplayMode(.large)
        .alert("Success", isPresented: $showingAlert) {
            Button("OK") { }
        } message: {
            Text(alertMessage)
        }


        .onAppear {
            // Initialize with red color
            updateValuesFromColor(colorModel.selectedColor)
        }
        .onChange(of: colorModel.selectedColor) { oldValue, newValue in
            updateValuesFromColor(newValue)
        }
    }
    
    @ViewBuilder
    var iPadLayout: some View {
        VStack(spacing: 30) {
            // Main picker area - First Priority
            HStack(alignment: .top, spacing: 40) {
                // Color picker square (Left)
                VStack(spacing: 15) {
                    Text("2D Color Picker")
                        .font(.headline)
                    
                    colorGradientSquare
                        .frame(width: 350, height: 350)
                }
                
                // Channel bar and controls (Right)
                VStack(spacing: 20) {
                    Text("Channel Control")
                        .font(.headline)
                    
                    channelBar
                        .frame(width: 60, height: 350)
                }
            }
            .padding(.horizontal, 30)
            
            // Detailed Mode Selection (iPad Only)
            iPadDetailedModeSelection
                .padding(.horizontal, 30)
            
            // Second row: Selected color display and color info
            HStack(alignment: .top, spacing: 40) {
                // Selected Color Display (Left side)
                VStack(spacing: 20) {
                    Text("Selected Color")
                        .font(.headline)
                    colorDisplaySection
                    
                    // Save to Library Button
                    saveButtonSection
                }
                .frame(maxWidth: 350)
                

            }
            .padding(.horizontal, 30)
            

        }
        .padding(.vertical, 20)
    }
    
    @ViewBuilder 
    var iPhoneLayout: some View {
        VStack(spacing: 25) {
            // 2D Color Picker and Channel Bar - First Priority
            HStack(alignment: .top, spacing: 20) {
                VStack(spacing: 10) {
                    Text("2D Color Picker")
                        .font(.headline)
                    
                    colorGradientSquare
                        .frame(width: 280, height: 280)
                }
                
                VStack(spacing: 10) {
                    Text("Channel")
                        .font(.headline)
                    
                    channelBar
                        .frame(width: 30, height: 280)
                }
            }
            .padding(.horizontal, 20)
            
            // Mode Selection
            modeSelectionSection
                .padding(.horizontal, 20)
            
            // Selected Color Display - Second Priority
            colorDisplaySection
                .padding(.horizontal, 20)
            
            // Save to Library Button
            saveButtonSection
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
        }
        .padding(.top, 10)
    }
    
    @ViewBuilder
    var landscapeLayout: some View {
        HStack(spacing: 0) {
            // Left side: Color picker area - First Priority
            VStack(spacing: 15) {
                // Large Color Picker, Channel, and Mode Selection in same row
                HStack(alignment: .top, spacing: 15) {
                    VStack(spacing: 10) {
                        Text("2D Color Picker")
                            .font(.headline)
                        colorGradientSquare
                            .frame(width: 400, height: 400)
                    }
                    
                    VStack(spacing: 10) {
                        Text("Channel")
                            .font(.headline)
                        channelBar
                            .frame(width: 45, height: 400)
                    }
                    
                    // Detailed Mode Selection in the same row
                    VStack(spacing: 10) {
                        Text("Color Mode")
                            .font(.headline)
                        iPadDetailedModeSelection
                            .frame(height: 400)
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.leading, 20)
            .padding(.trailing, 10)
            
            // Right side: Selected color and info - flexible width
            VStack(spacing: 25) {
                // Selected Color Display - Second Priority
                VStack(alignment: .leading, spacing: 15) {
                    Text("Selected Color")
                        .font(.headline)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    colorDisplaySection
                        .frame(height: 120)
                        .cornerRadius(15)
                }
                .padding(20)
                .background(Color(.systemGray6))
                .cornerRadius(15)
                
                // Save to Library Button
                saveButtonSection
                    .padding(.horizontal, 20)

            }
            .frame(minWidth: 300, maxWidth: .infinity)
            .padding(.trailing, 20)
            .padding(.leading, 10)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(.vertical, 20)
    }
    

    
    private func channelsForMode(_ mode: ColorMode) -> [ColorChannel] {
        switch mode {
        case .rgb: return [.red, .green, .blue]
        case .hsb: return [.hue, .saturation, .brightness]
        case .lab: return [.lightness, .aValue, .bValue]
        }
    }
    
    private func channelValueString(for channel: ColorChannel) -> String {
        switch channel {
        case .red: return "\(Int(rgbValues.r))"
        case .green: return "\(Int(rgbValues.g))"
        case .blue: return "\(Int(rgbValues.b))"
        case .hue: return "\(Int(hsbValues.h * 360))°"
        case .saturation: return "\(Int(hsbValues.s * 100))%"
        case .brightness: return "\(Int(hsbValues.b * 100))%"
        case .lightness: return "\(Int(labValues.l))"
        case .aValue: return "\(Int(labValues.a))"
        case .bValue: return "\(Int(labValues.b))"
        }
    }
    

    
    private func updateColorFromCurrentValues() {
        let color: Color
        
        switch currentMode {
        case .rgb:
            color = Color(
                red: rgbValues.r / 255.0,
                green: rgbValues.g / 255.0,
                blue: rgbValues.b / 255.0
            )
        case .hsb:
            color = Color(
                hue: hsbValues.h,
                saturation: hsbValues.s,
                brightness: hsbValues.b
            )
        case .lab:
            let labColor = ColorModel.ColorInfo.LAB(l: labValues.l, a: labValues.a, b: labValues.b)
            color = colorModel.labToColor(lab: labColor)
        }
        
        colorModel.selectedColor = color
        
        // Update other color spaces
        updateValuesFromColor(color)
    }
    
    private func updateValuesFromColor(_ color: Color) {
        let colorInfo = colorModel.createColorInfo(from: color)
        
        // Update RGB values
        rgbValues.r = Double(colorInfo.rgb.red)
        rgbValues.g = Double(colorInfo.rgb.green)
        rgbValues.b = Double(colorInfo.rgb.blue)
        
        // Update HSB values
        let uiColor = UIColor(color)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        uiColor.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
        hsbValues.h = Double(h)
        hsbValues.s = Double(s)
        hsbValues.b = Double(b)
        
        // Update LAB values
        labValues.l = colorInfo.lab.l
        labValues.a = colorInfo.lab.a
        labValues.b = colorInfo.lab.b
    }
    

    
    // Convert Color to hex string
    private func colorToHex(_ color: Color) -> String {
        let colorInfo = colorModel.createColorInfo(from: color)
        return colorInfo.hex
    }
    
    // MARK: - Section Views
    
    @ViewBuilder
    var colorInfoBoxSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Color Information")
                    .font(.headline)
                    .foregroundColor(.primary)
                Spacer()
                
                // Color preview square
                RoundedRectangle(cornerRadius: 8)
                    .fill(colorModel.selectedColor)
                    .frame(width: 32, height: 32)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                    .shadow(radius: 2)
                    .onTapGesture {
                        let colorInfo = colorModel.createColorInfo(from: colorModel.selectedColor)
                        UIPasteboard.general.string = colorInfo.hex
                    }
            }
            
            VStack(spacing: 8) {
                // Color name and hex
                let colorInfo = colorModel.createColorInfo(from: colorModel.selectedColor)
                
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Name")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(colorInfo.name)
                            .font(.subheadline)
                            .fontWeight(.medium)
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 4) {
                        Text("Hex")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text(colorInfo.hex.uppercased())
                            .font(.subheadline.monospaced())
                            .fontWeight(.medium)
                            .onTapGesture {
                                UIPasteboard.general.string = colorInfo.hex
                            }
                    }
                }
                
                Divider()
                
                // RGB Values
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("RGB")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("\(colorInfo.rgb.red), \(colorInfo.rgb.green), \(colorInfo.rgb.blue)")
                            .font(.subheadline.monospaced())
                    }
                    
                    Spacer()
                    
                    VStack(alignment: .trailing, spacing: 4) {
                        Text("HSL")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("\(Int(colorInfo.hsl.hue * 360))°, \(Int(colorInfo.hsl.saturation * 100))%, \(Int(colorInfo.hsl.lightness * 100))%")
                            .font(.subheadline.monospaced())
                    }
                }
                
                // LAB Values
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("LAB")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        Text("L: \(Int(colorInfo.lab.l)), a: \(Int(colorInfo.lab.a)), b: \(Int(colorInfo.lab.b))")
                            .font(.subheadline.monospaced())
                    }
                    
                    Spacer()
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color(.systemGray6))
        .cornerRadius(10)
    }
    
    @ViewBuilder
    var compactModeSelectionView: some View {
        VStack(spacing: 10) {
            Text("Color Mode")
                .font(.headline)
                .fontWeight(.semibold)
            
            // Horizontal layout of all three modes
            HStack(spacing: 12) {
                ForEach(ColorMode.allCases, id: \.self) { mode in
                    VStack(alignment: .leading, spacing: 8) {
                        // Mode title
                        Text(mode.rawValue.uppercased())
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                        
                        // Channel buttons for this mode
                        VStack(alignment: .leading, spacing: 4) {
                            ForEach(channelsForMode(mode), id: \.self) { channel in
                                HStack(spacing: 6) {
                                    Button(action: {
                                        selectedChannel = channel
                                        updateColorFromCurrentValues()
                                    }) {
                                        HStack(spacing: 4) {
                                            Image(systemName: selectedChannel == channel ? "largecircle.fill.circle" : "circle")
                                                .foregroundColor(selectedChannel == channel ? .blue : .gray)
                                                .font(.caption)
                                            
                                            Text(channel.displayName + ":")
                                                .font(.caption2)
                                                .foregroundColor(selectedChannel == channel ? .primary : .secondary)
                                        }
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                    
                                    Text(channelValueString(for: channel))
                                        .font(.caption2.monospaced())
                                        .foregroundColor(.secondary)
                                        .frame(width: 35, alignment: .leading)
                                }
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 10)
                    .background(currentMode == mode ? Color.blue.opacity(0.1) : Color.gray.opacity(0.05))
                    .cornerRadius(8)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 12)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
        }
        .frame(height: 400, alignment: .top)
    }
    
    @ViewBuilder
    var iPadDetailedModeSelection: some View {
        HStack(alignment: .top, spacing: 16) {
            // RGB Column
            VStack(alignment: .leading, spacing: 8) {
                Text("RGB")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.primary)
                
                VStack(spacing: 10) {
                    ForEach(channelsForMode(.rgb), id: \.self) { channel in
                        HStack(spacing: 8) {
                            Button(action: {
                                selectedChannel = channel
                                updateColorFromCurrentValues()
                            }) {
                                Image(systemName: selectedChannel == channel ? "largecircle.fill.circle" : "circle")
                                    .foregroundColor(selectedChannel == channel ? .blue : Color(.systemGray3))
                                    .font(.system(size: 20))
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            Text("\(channel.displayName):")
                                .font(.system(size: 16))
                                .foregroundColor(.primary)
                            
                            Text(channelValueString(for: channel))
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.secondary)
                            
                            Spacer()
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity)
            
            // HSB Column
            VStack(alignment: .leading, spacing: 8) {
                Text("HSB")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.primary)
                
                VStack(spacing: 10) {
                    ForEach(channelsForMode(.hsb), id: \.self) { channel in
                        HStack(spacing: 8) {
                            Button(action: {
                                selectedChannel = channel
                                updateColorFromCurrentValues()
                            }) {
                                Image(systemName: selectedChannel == channel ? "largecircle.fill.circle" : "circle")
                                    .foregroundColor(selectedChannel == channel ? .blue : Color(.systemGray3))
                                    .font(.system(size: 20))
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            Text("\(channel.displayName):")
                                .font(.system(size: 16))
                                .foregroundColor(.primary)
                            
                            Text(channelValueString(for: channel))
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.secondary)
                            
                            Spacer()
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity)
            
            // LAB Column
            VStack(alignment: .leading, spacing: 8) {
                Text("LAB")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.primary)
                
                VStack(spacing: 10) {
                    ForEach(channelsForMode(.lab), id: \.self) { channel in
                        HStack(spacing: 8) {
                            Button(action: {
                                selectedChannel = channel
                                updateColorFromCurrentValues()
                            }) {
                                Image(systemName: selectedChannel == channel ? "largecircle.fill.circle" : "circle")
                                    .foregroundColor(selectedChannel == channel ? .blue : Color(.systemGray3))
                                    .font(.system(size: 20))
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            Text("\(channel.displayName):")
                                .font(.system(size: 16))
                                .foregroundColor(.primary)
                            
                            Text(channelValueString(for: channel))
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.secondary)
                            
                            Spacer()
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity)
        }
        .padding(16)
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
    


    @ViewBuilder
    var modeSelectionSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Color Mode Selection")
                    .font(.headline)
                    .foregroundColor(.primary)
                Spacer()
            }
            
            // Simple horizontal 3-column layout for RGB, HSB, LAB
            HStack(spacing: 8) {
                ForEach(ColorMode.allCases, id: \.self) { mode in
                    Button(action: {
                        if let firstChannel = channelsForMode(mode).first {
                            selectedChannel = firstChannel
                        }
                        updateColorFromCurrentValues()
                    }) {
                        VStack(spacing: 12) {
                            Image(systemName: currentMode == mode ? "circle.fill" : "circle")
                                .foregroundColor(currentMode == mode ? .blue : .gray)
                                .font(.system(size: 32))
                            
                            Text(mode.rawValue)
                                .font(.headline)
                                .fontWeight(currentMode == mode ? .bold : .medium)
                                .foregroundColor(currentMode == mode ? .primary : .secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 20)
                        .background(currentMode == mode ? Color.blue.opacity(0.1) : Color.clear)
                        .cornerRadius(8)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(4)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
        }
    }
    
    @ViewBuilder
    var colorGradientSquare: some View {
        ColorGradientSquare(
            selectedChannel: selectedChannel,
            rgbValues: $rgbValues,
            hsbValues: $hsbValues,
            labValues: $labValues,
            colorModel: colorModel,
            onColorChange: { updateColorFromCurrentValues() }
        )
        .cornerRadius(8)
        .shadow(radius: 3)
    }
    
    @ViewBuilder
    var channelBar: some View {
        ChannelBar(
            selectedChannel: selectedChannel,
            rgbValues: $rgbValues,
            hsbValues: $hsbValues,
            labValues: $labValues,
            colorModel: colorModel,
            onValueChange: { updateColorFromCurrentValues() }
        )
        .cornerRadius(8)
        .shadow(radius: 3)
    }
    
    @ViewBuilder
    var colorDisplaySection: some View {
        // Selected Color Display (Tap to copy hex)
        RoundedRectangle(cornerRadius: 16)
            .fill(colorModel.selectedColor)
            .frame(height: isFullyExpandedLayout ? 120 : 80)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
            )
            .overlay(
                // Copy indicator overlay
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Image(systemName: "doc.on.doc")
                            .foregroundColor(.white)
                            .font(.caption)
                            .padding(4)
                            .background(Color.black.opacity(0.6))
                            .cornerRadius(4)
                            .padding(8)
                    }
                }
            )
            .shadow(radius: 5)
            .onTapGesture {
                let colorInfo = colorModel.createColorInfo(from: colorModel.selectedColor)
                UIPasteboard.general.string = colorInfo.hex
                showingAlert = true
                alertMessage = "Copied \(colorInfo.hex) to clipboard!"
            }
    }
    
    @ViewBuilder
    var saveButtonSection: some View {
        VStack(spacing: 12) {
            Button(action: {
                // Auto-generate name based on hex code or color name
                let colorInfo = colorModel.createColorInfo(from: colorModel.selectedColor)
                let autoName = "\(colorInfo.name) (\(colorInfo.hex.uppercased()))"
                colorModel.saveColorToLibrary(colorModel.selectedColor, name: autoName)
                showingAlert = true
                alertMessage = "Color saved to library!"
            }) {
                HStack {
                    Image(systemName: "bookmark.fill")
                    Text("Save to Library")
                }
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(LinearGradient(
                    gradient: Gradient(colors: [colorModel.selectedColor.opacity(0.8), colorModel.selectedColor]),
                    startPoint: .leading,
                    endPoint: .trailing
                ))
                .cornerRadius(12)
            }
        }
    }

}

struct ColorGradientSquare: View {
    let selectedChannel: ColorChannel
    @Binding var rgbValues: (r: Double, g: Double, b: Double)
    @Binding var hsbValues: (h: Double, s: Double, b: Double)
    @Binding var labValues: (l: Double, a: Double, b: Double)
    let colorModel: ColorModel
    let onColorChange: () -> Void
    
    @State private var cursorPosition = CGPoint(x: 140, y: 140)
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background gradient based on selected channel
                gradientForChannel
                
                // Cursor
                Circle()
                    .stroke(Color.white, lineWidth: 2)
                    .background(Circle().stroke(Color.black, lineWidth: 1))
                    .frame(width: 20, height: 20)
                    .position(cursorPosition)
            }
            .clipped()
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let newPosition = CGPoint(
                            x: max(10, min(geometry.size.width - 10, value.location.x)),
                            y: max(10, min(geometry.size.height - 10, value.location.y))
                        )
                        cursorPosition = newPosition
                        
                        updateValuesFromPosition(newPosition, geometry: geometry)
                        onColorChange()
                    }
            )
            .onChange(of: selectedChannel) { _, _ in
                updateCursorFromValues(geometry: geometry)
            }
        }
    }
    
    private var gradientForChannel: some View {
        Group {
            switch selectedChannel {
            case .hue:
                // HSB: Saturation vs Brightness with current hue
                ZStack {
                    Rectangle()
                        .fill(Color(hue: hsbValues.h, saturation: 1.0, brightness: 1.0))
                    LinearGradient(
                        gradient: Gradient(colors: [Color.white, Color.clear]),
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                    LinearGradient(
                        gradient: Gradient(colors: [Color.clear, Color.black]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                }
            case .saturation:
                // HSB: Hue vs Brightness with current saturation
                ZStack {
                    HueGradient()
                    LinearGradient(
                        gradient: Gradient(colors: [Color.clear, Color.black]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                }
            case .brightness:
                // HSB: Hue vs Saturation with current brightness
                HueGradient()
            case .red:
                // RGB: Green vs Blue with current red
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: rgbValues.r / 255.0, green: 0, blue: 0),
                        Color(red: rgbValues.r / 255.0, green: 0, blue: 1),
                        Color(red: rgbValues.r / 255.0, green: 1, blue: 0),
                        Color(red: rgbValues.r / 255.0, green: 1, blue: 1)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            case .green:
                // RGB: Red vs Blue with current green
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: 0, green: rgbValues.g / 255.0, blue: 0),
                        Color(red: 0, green: rgbValues.g / 255.0, blue: 1),
                        Color(red: 1, green: rgbValues.g / 255.0, blue: 0),
                        Color(red: 1, green: rgbValues.g / 255.0, blue: 1)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            case .blue:
                // RGB: Red vs Green with current blue
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: 0, green: 0, blue: rgbValues.b / 255.0),
                        Color(red: 0, green: 1, blue: rgbValues.b / 255.0),
                        Color(red: 1, green: 0, blue: rgbValues.b / 255.0),
                        Color(red: 1, green: 1, blue: rgbValues.b / 255.0)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            case .lightness:
                // LAB: a vs b with current lightness - Green/Red vs Blue/Yellow
                LABGradientView(
                    fixedL: labValues.l,
                    aRange: (-128.0, 127.0),
                    bRange: (-127.0, 128.0),
                    colorModel: colorModel
                )
            case .aValue:
                // LAB: lightness vs b with current a - Lightness vs Blue/Yellow
                LABGradientView(
                    fixedA: labValues.a,
                    lRange: (0.0, 100.0),
                    bRange: (-127.0, 128.0),
                    colorModel: colorModel
                )
            case .bValue:
                // LAB: lightness vs a with current b - Lightness vs Green/Red
                LABGradientView(
                    fixedB: labValues.b,
                    lRange: (0.0, 100.0),
                    aRange: (-128.0, 127.0),
                    colorModel: colorModel
                )
            }
        }
    }
    
    private func updateValuesFromPosition(_ position: CGPoint, geometry: GeometryProxy) {
        let x = position.x / geometry.size.width
        let y = position.y / geometry.size.height
        
        switch selectedChannel {
        case .hue:
            hsbValues.s = x
            hsbValues.b = 1.0 - y
        case .saturation:
            hsbValues.h = x
            hsbValues.b = 1.0 - y
        case .brightness:
            hsbValues.h = x
            hsbValues.s = 1.0 - y
        case .red:
            rgbValues.g = x * 255
            rgbValues.b = (1.0 - y) * 255
        case .green:
            rgbValues.r = x * 255
            rgbValues.b = (1.0 - y) * 255
        case .blue:
            rgbValues.r = x * 255
            rgbValues.g = (1.0 - y) * 255
        case .lightness:
            labValues.a = (x - 0.5) * 256 // -128 to +127
            labValues.b = (0.5 - y) * 256 // -128 to +127
        case .aValue:
            labValues.l = (1.0 - y) * 100 // 0 to 100
            labValues.b = (x - 0.5) * 256 // -128 to +127
        case .bValue:
            labValues.l = (1.0 - y) * 100 // 0 to 100
            labValues.a = (x - 0.5) * 256 // -128 to +127
        }
    }
    
    private func updateCursorFromValues(geometry: GeometryProxy) {
        let position: CGPoint
        
        switch selectedChannel {
        case .hue:
            position = CGPoint(
                x: hsbValues.s * geometry.size.width,
                y: (1.0 - hsbValues.b) * geometry.size.height
            )
        case .saturation:
            position = CGPoint(
                x: hsbValues.h * geometry.size.width,
                y: (1.0 - hsbValues.b) * geometry.size.height
            )
        case .brightness:
            position = CGPoint(
                x: hsbValues.h * geometry.size.width,
                y: (1.0 - hsbValues.s) * geometry.size.height
            )
        case .red:
            position = CGPoint(
                x: (rgbValues.g / 255.0) * geometry.size.width,
                y: (1.0 - rgbValues.b / 255.0) * geometry.size.height
            )
        case .green:
            position = CGPoint(
                x: (rgbValues.r / 255.0) * geometry.size.width,
                y: (1.0 - rgbValues.b / 255.0) * geometry.size.height
            )
        case .blue:
            position = CGPoint(
                x: (rgbValues.r / 255.0) * geometry.size.width,
                y: (1.0 - rgbValues.g / 255.0) * geometry.size.height
            )
        case .lightness:
            position = CGPoint(
                x: (labValues.a + 128) / 256 * geometry.size.width,
                y: (1.0 - (labValues.b + 128) / 256) * geometry.size.height
            )
        case .aValue:
            position = CGPoint(
                x: (labValues.b + 128) / 256 * geometry.size.width,
                y: (1.0 - labValues.l / 100) * geometry.size.height
            )
        case .bValue:
            position = CGPoint(
                x: (labValues.a + 128) / 256 * geometry.size.width,
                y: (1.0 - labValues.l / 100) * geometry.size.height
            )
        }
        
        cursorPosition = position
    }
}

struct HueGradient: View {
    var body: some View {
        LinearGradient(
            gradient: Gradient(colors: [
                Color(hue: 0, saturation: 1, brightness: 1),      // Red
                Color(hue: 0.17, saturation: 1, brightness: 1),   // Yellow
                Color(hue: 0.33, saturation: 1, brightness: 1),   // Green
                Color(hue: 0.5, saturation: 1, brightness: 1),    // Cyan
                Color(hue: 0.67, saturation: 1, brightness: 1),   // Blue
                Color(hue: 0.83, saturation: 1, brightness: 1),   // Magenta
                Color(hue: 1, saturation: 1, brightness: 1)       // Red
            ]),
            startPoint: .leading,
            endPoint: .trailing
        )
    }
}

struct ChannelBar: View {
    let selectedChannel: ColorChannel
    @Binding var rgbValues: (r: Double, g: Double, b: Double)
    @Binding var hsbValues: (h: Double, s: Double, b: Double)
    @Binding var labValues: (l: Double, a: Double, b: Double)
    let colorModel: ColorModel  // Add colorModel parameter
    let onValueChange: () -> Void
    
    @State private var cursorY: CGFloat = 0
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Bar gradient based on selected channel
                gradientForChannel
                
                // Cursor
                RoundedRectangle(cornerRadius: 2)
                    .stroke(Color.white, lineWidth: 2)
                    .background(RoundedRectangle(cornerRadius: 2).stroke(Color.black, lineWidth: 1))
                    .frame(width: geometry.size.width + 4, height: 8)
                    .position(x: geometry.size.width / 2, y: cursorY)
            }
            .clipped()
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let newY = max(4, min(geometry.size.height - 4, value.location.y))
                        cursorY = newY
                        
                        updateValueFromPosition(newY, geometry: geometry)
                        onValueChange()
                    }
            )
            .onChange(of: selectedChannel) { _, _ in
                updateCursorFromValue(geometry: geometry)
            }
        }
    }
    
    private var gradientForChannel: some View {
        Group {
            switch selectedChannel {
            case .hue:
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(hue: 0, saturation: 1, brightness: 1),      // Red
                        Color(hue: 0.17, saturation: 1, brightness: 1),   // Yellow
                        Color(hue: 0.33, saturation: 1, brightness: 1),   // Green
                        Color(hue: 0.5, saturation: 1, brightness: 1),    // Cyan
                        Color(hue: 0.67, saturation: 1, brightness: 1),   // Blue
                        Color(hue: 0.83, saturation: 1, brightness: 1),   // Magenta
                        Color(hue: 1, saturation: 1, brightness: 1)       // Red
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .saturation:
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(hue: hsbValues.h, saturation: 0, brightness: hsbValues.b),
                        Color(hue: hsbValues.h, saturation: 1, brightness: hsbValues.b)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .brightness:
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(hue: hsbValues.h, saturation: hsbValues.s, brightness: 0),
                        Color(hue: hsbValues.h, saturation: hsbValues.s, brightness: 1)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .red:
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: 0, green: rgbValues.g / 255.0, blue: rgbValues.b / 255.0),
                        Color(red: 1, green: rgbValues.g / 255.0, blue: rgbValues.b / 255.0)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .green:
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: rgbValues.r / 255.0, green: 0, blue: rgbValues.b / 255.0),
                        Color(red: rgbValues.r / 255.0, green: 1, blue: rgbValues.b / 255.0)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .blue:
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color(red: rgbValues.r / 255.0, green: rgbValues.g / 255.0, blue: 0),
                        Color(red: rgbValues.r / 255.0, green: rgbValues.g / 255.0, blue: 1)
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .lightness:
                LinearGradient(
                    gradient: Gradient(colors: [
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: 0, a: labValues.a, b: labValues.b)),
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: 50, a: labValues.a, b: labValues.b)),
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: 100, a: labValues.a, b: labValues.b))
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .aValue:
                LinearGradient(
                    gradient: Gradient(colors: [
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: labValues.l, a: -128, b: labValues.b)), // Green
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: labValues.l, a: 0, b: labValues.b)),   // Neutral
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: labValues.l, a: 127, b: labValues.b))  // Red
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            case .bValue:
                LinearGradient(
                    gradient: Gradient(colors: [
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: labValues.l, a: labValues.a, b: -128)), // Blue
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: labValues.l, a: labValues.a, b: 0)),   // Neutral
                        colorModel.labToColor(lab: ColorModel.ColorInfo.LAB(l: labValues.l, a: labValues.a, b: 127))  // Yellow
                    ]),
                    startPoint: .top,
                    endPoint: .bottom
                )
            }
        }
    }
    
    private func updateValueFromPosition(_ y: CGFloat, geometry: GeometryProxy) {
        let normalizedY = y / geometry.size.height
        
        switch selectedChannel {
        case .hue:
            hsbValues.h = normalizedY
        case .saturation:
            hsbValues.s = normalizedY
        case .brightness:
            hsbValues.b = normalizedY
        case .red:
            rgbValues.r = normalizedY * 255
        case .green:
            rgbValues.g = normalizedY * 255
        case .blue:
            rgbValues.b = normalizedY * 255
        case .lightness:
            labValues.l = normalizedY * 100
        case .aValue:
            labValues.a = (normalizedY - 0.5) * 256 // -128 to +127
        case .bValue:
            labValues.b = (normalizedY - 0.5) * 256 // -128 to +127
        }
    }
    
    private func updateCursorFromValue(geometry: GeometryProxy) {
        let y: CGFloat
        
        switch selectedChannel {
        case .hue:
            y = CGFloat(hsbValues.h) * geometry.size.height
        case .saturation:
            y = CGFloat(hsbValues.s) * geometry.size.height
        case .brightness:
            y = CGFloat(hsbValues.b) * geometry.size.height
        case .red:
            y = CGFloat(rgbValues.r / 255.0) * geometry.size.height
        case .green:
            y = CGFloat(rgbValues.g / 255.0) * geometry.size.height
        case .blue:
            y = CGFloat(rgbValues.b / 255.0) * geometry.size.height
        case .lightness:
            y = CGFloat(labValues.l / 100.0) * geometry.size.height
        case .aValue:
            y = CGFloat((labValues.a + 128) / 256.0) * geometry.size.height
        case .bValue:
            y = CGFloat((labValues.b + 128) / 256.0) * geometry.size.height
        }
        
        cursorY = y
    }
}



struct LABGradientView: View {
    let fixedL: Double?
    let fixedA: Double?
    let fixedB: Double?
    let lRange: (Double, Double)?
    let aRange: (Double, Double)?
    let bRange: (Double, Double)?
    let colorModel: ColorModel
    
    init(fixedL: Double, aRange: (Double, Double), bRange: (Double, Double), colorModel: ColorModel) {
        self.fixedL = fixedL
        self.fixedA = nil
        self.fixedB = nil
        self.lRange = nil
        self.aRange = aRange
        self.bRange = bRange
        self.colorModel = colorModel
    }
    
    init(fixedA: Double, lRange: (Double, Double), bRange: (Double, Double), colorModel: ColorModel) {
        self.fixedL = nil
        self.fixedA = fixedA
        self.fixedB = nil
        self.lRange = lRange
        self.aRange = nil
        self.bRange = bRange
        self.colorModel = colorModel
    }
    
    init(fixedB: Double, lRange: (Double, Double), aRange: (Double, Double), colorModel: ColorModel) {
        self.fixedL = nil
        self.fixedA = nil
        self.fixedB = fixedB
        self.lRange = lRange
        self.aRange = aRange
        self.bRange = nil
        self.colorModel = colorModel
    }
    
    var body: some View {
        GeometryReader { geometry in
            Canvas { context, size in
                // High-quality LAB color space sampling (like HTML version)
                let width = Int(size.width)
                let height = Int(size.height)
                let stepX = max(1, width / 280) // Sample every few pixels for performance
                let stepY = max(1, height / 280)
                
                for x in stride(from: 0, to: width, by: stepX) {
                    for y in stride(from: 0, to: height, by: stepY) {
                        let normalizedX = Double(x) / Double(width - 1)
                        let normalizedY = 1.0 - (Double(y) / Double(height - 1)) // Flip Y
                        
                        let (l, a, b) = calculateLABValues(normalizedX: normalizedX, normalizedY: normalizedY)
                        let labColor = ColorModel.ColorInfo.LAB(l: l, a: a, b: b)
                        let color = colorModel.labToColor(lab: labColor)
                        
                        // Draw a small rectangle for this sample
                        let rect = CGRect(x: x, y: y, width: stepX, height: stepY)
                        context.fill(Path(rect), with: .color(color))
                    }
                }
            }
        }
    }
    
    private func calculateLABValues(normalizedX: Double, normalizedY: Double) -> (Double, Double, Double) {
        if let fixedL = fixedL {
            // L is fixed, vary a (x-axis) and b (y-axis)
            // Map normalized coordinates to LAB ranges
            let a = aRange!.0 + normalizedX * (aRange!.1 - aRange!.0)
            let b = bRange!.0 + normalizedY * (bRange!.1 - bRange!.0)
            return (fixedL, a, b)
        } else if let fixedA = fixedA {
            // a is fixed, vary L (y-axis) and b (x-axis)
            let l = lRange!.0 + normalizedY * (lRange!.1 - lRange!.0)
            let b = bRange!.0 + normalizedX * (bRange!.1 - bRange!.0)
            return (l, fixedA, b)
        } else if let fixedB = fixedB {
            // b is fixed, vary L (y-axis) and a (x-axis)
            let l = lRange!.0 + normalizedY * (lRange!.1 - lRange!.0)
            let a = aRange!.0 + normalizedX * (aRange!.1 - aRange!.0)
            return (l, a, fixedB)
        }
        
        return (50, 0, 0) // fallback
    }
}

