import SwiftUI
import Foundation

class ColorModel: ObservableObject {
    @Published var selectedColor: Color = .red
    @Published var colorLibrary: [LibraryColor] = []
    
    struct ColorInfo: Identifiable {
        let id = UUID()
        let color: Color
        let name: String
        let hex: String
        let rgb: RGB
        let hsl: HSL
        let lab: LAB
        let timestamp: Date
        
        struct RGB {
            let red: Int
            let green: Int
            let blue: Int
        }
        
        struct HSL {
            let hue: Double
            let saturation: Double
            let lightness: Double
        }
        
        struct LAB {
            let l: Double  // Lightness: 0-100
            let a: Double  // Green-Red: -128 to +127
            let b: Double  // Blue-Yellow: -128 to +127
        }
    }
    
    struct LibraryColor: Identifiable, Codable {
        let id: String
        let name: String
        let hex: String
        let rgb: RGB
        let hsl: HSL
        let lab: LAB
        let dateAdded: Date
        
        init(name: String, hex: String, rgb: RGB, hsl: HSL, lab: LAB, dateAdded: Date) {
            self.id = UUID().uuidString
            self.name = name
            self.hex = hex
            self.rgb = rgb
            self.hsl = hsl
            self.lab = lab
            self.dateAdded = dateAdded
        }
        
        init(id: String, name: String, hex: String, rgb: RGB, hsl: HSL, lab: LAB, dateAdded: Date) {
            self.id = id
            self.name = name
            self.hex = hex
            self.rgb = rgb
            self.hsl = hsl
            self.lab = lab
            self.dateAdded = dateAdded
        }
        
        struct RGB: Codable {
            let red: Int
            let green: Int
            let blue: Int
        }
        
        struct HSL: Codable {
            let hue: Double
            let saturation: Double
            let lightness: Double
        }
        
        struct LAB: Codable {
            let l: Double
            let a: Double
            let b: Double
        }
        
        var color: Color {
            Color(red: Double(rgb.red) / 255.0,
                  green: Double(rgb.green) / 255.0,
                  blue: Double(rgb.blue) / 255.0)
        }
    }
    
    init() {
        loadColorLibrary()
    }
    
    func saveColorToLibrary(_ color: Color, name: String) {
        let colorInfo = createColorInfo(from: color)
        let libraryColor = LibraryColor(
            name: name,
            hex: colorInfo.hex,
            rgb: LibraryColor.RGB(red: colorInfo.rgb.red, green: colorInfo.rgb.green, blue: colorInfo.rgb.blue),
            hsl: LibraryColor.HSL(hue: colorInfo.hsl.hue, saturation: colorInfo.hsl.saturation, lightness: colorInfo.hsl.lightness),
            lab: LibraryColor.LAB(l: colorInfo.lab.l, a: colorInfo.lab.a, b: colorInfo.lab.b),
            dateAdded: Date()
        )
        
        colorLibrary.insert(libraryColor, at: 0)
        saveColorLibrary()
    }
    
    func removeColorFromLibrary(_ libraryColor: LibraryColor) {
        colorLibrary.removeAll { $0.id == libraryColor.id }
        saveColorLibrary()
    }
    
    func updateLibraryColorName(_ libraryColor: LibraryColor, newName: String) {
        if let index = colorLibrary.firstIndex(where: { $0.id == libraryColor.id }) {
            let updatedColor = LibraryColor(
                id: libraryColor.id,
                name: newName,
                hex: libraryColor.hex,
                rgb: libraryColor.rgb,
                hsl: libraryColor.hsl,
                lab: libraryColor.lab,
                dateAdded: libraryColor.dateAdded
            )
            colorLibrary[index] = updatedColor
            saveColorLibrary()
        }
    }
    
    private func saveColorLibrary() {
        if let encoded = try? JSONEncoder().encode(colorLibrary) {
            UserDefaults.standard.set(encoded, forKey: "ColorLibrary")
        }
    }
    
    private func loadColorLibrary() {
        if let data = UserDefaults.standard.data(forKey: "ColorLibrary"),
           let decoded = try? JSONDecoder().decode([LibraryColor].self, from: data) {
            colorLibrary = decoded
        }
    }
    
    func createColorInfo(from color: Color) -> ColorInfo {
        let uiColor = UIColor(color)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        
        uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        let rgb = ColorInfo.RGB(
            red: Int(red * 255),
            green: Int(green * 255),
            blue: Int(blue * 255)
        )
        
        let hex = String(format: "#%02X%02X%02X", rgb.red, rgb.green, rgb.blue)
        
        // Convert to HSL
        let hsl = rgbToHSL(rgb: rgb)
        
        // Convert to LAB
        let lab = colorToLab(color) // Use the new accurate LAB conversion
        
        let name = getColorName(for: rgb)
        
        return ColorInfo(
            color: color,
            name: name,
            hex: hex,
            rgb: rgb,
            hsl: hsl,
            lab: lab,
            timestamp: Date()
        )
    }
    
    private func rgbToHSL(rgb: ColorInfo.RGB) -> ColorInfo.HSL {
        let r = Double(rgb.red) / 255.0
        let g = Double(rgb.green) / 255.0
        let b = Double(rgb.blue) / 255.0
        
        let max = Swift.max(r, g, b)
        let min = Swift.min(r, g, b)
        let diff = max - min
        
        var h: Double = 0
        let s: Double
        let l: Double = (max + min) / 2
        
        if diff == 0 {
            s = 0
        } else {
            s = l > 0.5 ? diff / (2 - max - min) : diff / (max + min)
            
            switch max {
            case r:
                h = (g - b) / diff + (g < b ? 6 : 0)
            case g:
                h = (b - r) / diff + 2
            case b:
                h = (r - g) / diff + 4
            default:
                break
            }
            h /= 6
        }
        
        return ColorInfo.HSL(
            hue: h * 360,
            saturation: s * 100,
            lightness: l * 100
        )
    }
    
    // Accurate LAB to RGB conversion (based on www.easyrgb.com algorithms)
    func labToColor(lab: ColorInfo.LAB) -> Color {
        // LAB to XYZ conversion
        var y = (lab.l + 16) / 116
        var x = lab.a / 500 + y
        var z = y - lab.b / 200
        
        // XYZ scaling with proper illuminant D65 values
        x = 0.95047 * ((x * x * x > 0.008856) ? x * x * x : (x - 16/116) / 7.787)
        y = 1.00000 * ((y * y * y > 0.008856) ? y * y * y : (y - 16/116) / 7.787)
        z = 1.08883 * ((z * z * z > 0.008856) ? z * z * z : (z - 16/116) / 7.787)
        
        // XYZ to RGB conversion with sRGB matrix
        var r = x *  3.2406 + y * -1.5372 + z * -0.4986
        var g = x * -0.9689 + y *  1.8758 + z *  0.0415
        var b = x *  0.0557 + y * -0.2040 + z *  1.0570
        
        // Gamma correction for sRGB
        r = (r > 0.0031308) ? (1.055 * pow(r, 1/2.4) - 0.055) : 12.92 * r
        g = (g > 0.0031308) ? (1.055 * pow(g, 1/2.4) - 0.055) : 12.92 * g
        b = (b > 0.0031308) ? (1.055 * pow(b, 1/2.4) - 0.055) : 12.92 * b
        
        // Clamp to valid range [0, 1]
        r = max(0, min(1, r))
        g = max(0, min(1, g))
        b = max(0, min(1, b))
        
        return Color(red: r, green: g, blue: b)
    }
    
    // Accurate RGB to LAB conversion (based on www.easyrgb.com algorithms)
    func colorToLab(_ color: Color) -> ColorInfo.LAB {
        let components = color.cgColor?.components ?? [0, 0, 0, 1]
        var r = Double(components[0])
        var g = Double(components[1])
        var b = Double(components[2])
        
        // Inverse gamma correction
        r = (r > 0.04045) ? pow((r + 0.055) / 1.055, 2.4) : r / 12.92
        g = (g > 0.04045) ? pow((g + 0.055) / 1.055, 2.4) : g / 12.92
        b = (b > 0.04045) ? pow((b + 0.055) / 1.055, 2.4) : b / 12.92
        
        // RGB to XYZ conversion with sRGB matrix and illuminant D65 scaling
        var x = (r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047
        var y = (r * 0.2126 + g * 0.7152 + b * 0.0722) / 1.00000
        var z = (r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883
        
        // XYZ to LAB conversion
        x = (x > 0.008856) ? pow(x, 1.0/3.0) : (7.787 * x) + 16.0/116.0
        y = (y > 0.008856) ? pow(y, 1.0/3.0) : (7.787 * y) + 16.0/116.0
        z = (z > 0.008856) ? pow(z, 1.0/3.0) : (7.787 * z) + 16.0/116.0
        
        let l = (116 * y) - 16
        let a = 500 * (x - y)
        let b_val = 200 * (y - z)
        
        return ColorInfo.LAB(l: l, a: a, b: b_val)
    }
    
    private func getColorName(for rgb: ColorInfo.RGB) -> String {
        // Simple color name detection based on RGB values
        let total = rgb.red + rgb.green + rgb.blue
        
        if total < 50 {
            return "Black"
        } else if total > 700 {
            return "White"
        } else if rgb.red > rgb.green && rgb.red > rgb.blue {
            if rgb.green > 100 {
                return "Orange"
            } else {
                return "Red"
            }
        } else if rgb.green > rgb.red && rgb.green > rgb.blue {
            return "Green"
        } else if rgb.blue > rgb.red && rgb.blue > rgb.green {
            return "Blue"
        } else if rgb.red > 150 && rgb.green > 150 && rgb.blue < 100 {
            return "Yellow"
        } else if rgb.red > 150 && rgb.blue > 150 && rgb.green < 100 {
            return "Magenta"
        } else if rgb.green > 150 && rgb.blue > 150 && rgb.red < 100 {
            return "Cyan"
        } else {
            return "Gray"
        }
    }
} 