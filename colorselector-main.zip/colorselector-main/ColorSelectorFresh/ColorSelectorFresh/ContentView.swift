import SwiftUI

enum NavigationItem: String, CaseIterable, Identifiable {
    case colorPicker = "Color Picker"
    case library = "Library"
    case converter = "Converter"
    
    var id: String { rawValue }
    
    var systemImage: String {
        switch self {
        case .colorPicker: return "paintpalette"
        case .library: return "bookmark.fill"
        case .converter: return "arrow.2.squarepath"
        }
    }
}

struct ContentView: View {
    @StateObject private var colorModel = ColorModel()
    @State private var selectedItem: NavigationItem = .colorPicker
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    
    var isLandscape: Bool {
        verticalSizeClass == .compact
    }
    
    var body: some View {
        // Use TabView for all iPad orientations - full width guaranteed
        TabView(selection: $selectedItem) {
            ColorPickerView(colorModel: colorModel)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .tabItem {
                    Image(systemName: "paintpalette")
                    Text("Color Picker")
                }
                .tag(NavigationItem.colorPicker)
            
            ColorLibraryView(colorModel: colorModel)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .tabItem {
                    Image(systemName: "bookmark.fill")
                    Text("Library")
                }
                .tag(NavigationItem.library)
            
            ColorConverterView(colorModel: colorModel)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .tabItem {
                    Image(systemName: "arrow.2.squarepath")
                    Text("Converter")
                }
                .tag(NavigationItem.converter)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .edgesIgnoringSafeArea([])
    }
}

