import SwiftUI

struct ColorLibraryView: View {
    @ObservedObject var colorModel: ColorModel
    @State private var showingDeleteAlert = false
    @State private var colorToDelete: ColorModel.LibraryColor?
    @State private var showingCopyAlert = false
    @State private var copyFeedbackMessage = ""
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    
    var isRegularLayout: Bool {
        horizontalSizeClass == .regular && verticalSizeClass == .regular
    }
    
    var isLandscapeLayout: Bool {
        horizontalSizeClass == .regular && verticalSizeClass == .compact
    }
    
    var isFullyExpandedLayout: Bool {
        isRegularLayout || isLandscapeLayout
    }
    
    var body: some View {
        VStack {
            if colorModel.colorLibrary.isEmpty {
                emptyStateView
            } else {
                if isFullyExpandedLayout {
                    iPadLibraryLayout
                } else {
                    iPhoneLibraryLayout
                }
            }
        }
        .navigationTitle("Color Library")
        .alert("Delete Color", isPresented: $showingDeleteAlert) {
            Button("Delete", role: .destructive) {
                if let color = colorToDelete {
                    colorModel.removeColorFromLibrary(color)
                    colorToDelete = nil
                }
            }
            Button("Cancel", role: .cancel) {
                colorToDelete = nil
            }
        } message: {
            Text("Are you sure you want to delete this color?")
        }
        .alert("Copied!", isPresented: $showingCopyAlert) {
            Button("OK") { }
        } message: {
            Text(copyFeedbackMessage)
        }
    }
    
    @ViewBuilder
    var emptyStateView: some View {
        Spacer()
        VStack(spacing: 20) {
            Image(systemName: "bookmark")
                .font(.system(size: 50))
                .foregroundColor(.gray)
            
            Text("No Saved Colors")
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text("Save colors from the Color Picker to build your personal library")
                .font(.body)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        Spacer()
    }
    
    @ViewBuilder
    var iPhoneLibraryLayout: some View {
        List {
            ForEach(colorModel.colorLibrary) { libraryColor in
                ColorLibraryRow(
                    libraryColor: libraryColor,
                    copyAction: {
                        copyColorToClipboard(libraryColor)
                    },
                    deleteAction: {
                        promptDeleteColor(libraryColor)
                    },
                    selectAction: {
                        selectColor(libraryColor)
                    }
                )
            }
        }
        .listStyle(PlainListStyle())
    }
    
    @ViewBuilder
    var iPadLibraryLayout: some View {
        ScrollView {
            LazyVGrid(columns: gridColumns, spacing: 20) {
                ForEach(colorModel.colorLibrary) { libraryColor in
                    ColorLibraryCard(
                        libraryColor: libraryColor,
                        copyAction: {
                            copyColorToClipboard(libraryColor)
                        },
                        deleteAction: {
                            promptDeleteColor(libraryColor)
                        },
                        selectAction: {
                            selectColor(libraryColor)
                        }
                    )
                }
            }
            .padding(20)
        }
    }
    
    var gridColumns: [GridItem] {
        let columnCount = isLandscapeLayout ? 4 : 3
        return Array(repeating: GridItem(.flexible(), spacing: 20), count: columnCount)
    }
    
    private func copyColorToClipboard(_ libraryColor: ColorModel.LibraryColor) {
        UIPasteboard.general.string = libraryColor.hex
        copyFeedbackMessage = "Hex code copied: \(libraryColor.hex)"
        showingCopyAlert = true
    }
    
    private func promptDeleteColor(_ libraryColor: ColorModel.LibraryColor) {
        colorToDelete = libraryColor
        showingDeleteAlert = true
    }
    
    private func selectColor(_ libraryColor: ColorModel.LibraryColor) {
        colorModel.selectedColor = libraryColor.color
    }
}

struct ColorLibraryRow: View {
    let libraryColor: ColorModel.LibraryColor
    let copyAction: () -> Void
    let deleteAction: () -> Void
    let selectAction: () -> Void
    
    var body: some View {
        HStack(spacing: 15) {
            // Color preview
            Button(action: selectAction) {
                RoundedRectangle(cornerRadius: 8)
                    .fill(libraryColor.color)
                    .frame(width: 50, height: 50)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
            }
            
            // Color info
            VStack(alignment: .leading, spacing: 4) {
                Text(libraryColor.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Button(action: copyAction) {
                    Text(libraryColor.hex.uppercased())
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .buttonStyle(PlainButtonStyle())
                
                Text("Added \(libraryColor.dateAdded.formatted(date: .abbreviated, time: .omitted))")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            // Action buttons - Only Copy and Delete
            HStack(spacing: 15) {
                // Copy Button
                Button {
                    copyAction()
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "doc.on.doc")
                            .font(.title3)
                        Text("Copy")
                            .font(.caption2)
                    }
                    .foregroundColor(.blue)
                }
                .buttonStyle(PlainButtonStyle())
                
                // Delete Button
                Button {
                    deleteAction()
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "trash")
                            .font(.title3)
                        Text("Delete")
                            .font(.caption2)
                    }
                    .foregroundColor(.red)
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding(.vertical, 8)
    }
}

struct ColorLibraryCard: View {
    let libraryColor: ColorModel.LibraryColor
    let copyAction: () -> Void
    let deleteAction: () -> Void
    let selectAction: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            // Color preview
            Button(action: selectAction) {
                RoundedRectangle(cornerRadius: 12)
                    .fill(libraryColor.color)
                    .frame(height: 100)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
            }
            
            VStack(spacing: 6) {
                Text(libraryColor.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                
                Button(action: copyAction) {
                    Text(libraryColor.hex.uppercased())
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .buttonStyle(PlainButtonStyle())
            }
            
            // Action buttons - Only Copy and Delete
            HStack(spacing: 20) {
                // Copy Button
                Button {
                    copyAction()
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: "doc.on.doc")
                            .font(.title3)
                        Text("Copy")
                            .font(.caption2)
                    }
                    .foregroundColor(.blue)
                    .frame(minWidth: 40)
                }
                .buttonStyle(PlainButtonStyle())
                
                // Delete Button
                Button {
                    deleteAction()
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: "trash")
                            .font(.title3)
                        Text("Delete")
                            .font(.caption2)
                    }
                    .foregroundColor(.red)
                    .frame(minWidth: 40)
                }
                .buttonStyle(PlainButtonStyle())
            }
        }
        .padding(15)
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
} 