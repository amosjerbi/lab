import SwiftUI

struct ColorConverterView: View {
    @ObservedObject var colorModel: ColorModel
    @State private var hexInput = "#FF0000"
    @State private var rgbRed: Double = 255
    @State private var rgbGreen: Double = 0
    @State private var rgbBlue: Double = 0
    @State private var hslHue: Double = 0
    @State private var hslSaturation: Double = 1
    @State private var hslLightness: Double = 0.5
    @State private var labL: Double = 50
    @State private var labA: Double = 0
    @State private var labB: Double = 0
    @State private var convertedColor: Color = .red
    @State private var showingAlert = false
    @State private var alertMessage = ""
    @State private var showingCopyAlert = false
    @State private var copyFeedbackMessage = ""
    @State private var showingLibrarySuccessAlert = false
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    
    var isRegularLayout: Bool {
        horizontalSizeClass == .regular && verticalSizeClass == .regular
    }
    
    var isLandscapeLayout: Bool {
        horizontalSizeClass == .regular && verticalSizeClass == .compact
    }
    
    var isFullyExpandedLayout: Bool {
        isRegularLayout || isLandscapeLayout
    }
    
    var body: some View {
        ScrollView {
            if isLandscapeLayout {
                landscapeLayout
            } else if isRegularLayout {
                iPadLayout
            } else {
                iPhoneLayout
            }
        }
        .navigationTitle("Color Converter")
        .navigationBarTitleDisplayMode(.large)
        .onAppear {
            updateFromColor()
        }
        .alert("Success", isPresented: $showingAlert) {
            Button("OK") { }
        } message: {
            Text(alertMessage)
        }
        .alert("Copied!", isPresented: $showingCopyAlert) {
            Button("OK") { }
        } message: {
            Text(copyFeedbackMessage)
        }
        .alert("Success", isPresented: $showingLibrarySuccessAlert) {
            Button("OK") { }
        } message: {
            Text("Color saved to library!")
        }
    }
    
    @ViewBuilder
    var iPadLayout: some View {
        VStack(spacing: 40) {
            // Top section: Color display and Hex input
            HStack(alignment: .top, spacing: 40) {
                // Color Display
                VStack(spacing: 15) {
                    Text("Current Color")
                        .font(.headline)
                    
                    colorDisplaySection
                        .frame(height: 150)
                }
                .frame(maxWidth: 300)
                
                // Hex Input
                VStack(spacing: 15) {
                    Text("Hex Input")
                        .font(.headline)
                    
                    hexInputSection
                }
                .frame(maxWidth: 300)
                
                // Color Information
                VStack(spacing: 15) {
                    colorInfoSection
                }
                .frame(maxWidth: 350)
            }
            .padding(.horizontal, 40)
            
            // Color sliders in two columns
            HStack(alignment: .top, spacing: 60) {
                // Left column: RGB and HSL
                VStack(spacing: 30) {
                    rgbSlidersSection
                    hslSlidersSection
                }
                .frame(maxWidth: 400)
                
                // Right column: LAB
                VStack(spacing: 30) {
                    labSlidersSection
                    Spacer(minLength: 100) // Balance the layout
                }
                .frame(maxWidth: 400)
            }
            .padding(.horizontal, 40)
            
            // Action buttons
            actionButtonsSection
                .padding(.horizontal, 40)
            
            // Saved Colors Section
            VStack(spacing: 20) {
                saveButtonSection
                    .frame(maxWidth: 400)
                presetColorsSection
                    .frame(maxWidth: 600)
            }
            .padding(.horizontal, 40)
        }
        .padding(.vertical, 30)
    }
    
    @ViewBuilder
    var iPhoneLayout: some View {
        VStack(spacing: 25) {
            // Color Display
            colorDisplaySection
                .frame(height: 100)
                .padding(.horizontal, 20)
            
            // Color Information Section
            colorInfoSection
                .padding(.horizontal, 20)
            
            // Hex Input Section
            hexInputSection
                .padding(.horizontal, 20)
            
            // RGB Sliders
            rgbSlidersSection
                .padding(.horizontal, 20)
            
            // HSL Sliders
            hslSlidersSection
                .padding(.horizontal, 20)
            
            // LAB Sliders
            labSlidersSection
                .padding(.horizontal, 20)
            
            // Action Buttons
            actionButtonsSection
                .padding(.horizontal, 20)
            
            // Save Button
            saveButtonSection
                .padding(.horizontal, 20)
            
            // Saved Colors Grid
            presetColorsSection
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
        }
        .padding(.top, 10)
    }
    
    @ViewBuilder
    var landscapeLayout: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(spacing: 20) {
                // Top row: Color display, hex input, and color information
                HStack(alignment: .top, spacing: 20) {
                    // Color Display
                    VStack(spacing: 15) {
                        Text("Current Color")
                            .font(.headline)
                        
                        colorDisplaySection
                            .frame(height: 120)
                    }
                    .frame(maxWidth: .infinity)
                    
                    // Hex Input
                    VStack(spacing: 15) {
                        Text("Hex Input")
                            .font(.headline)
                        
                        hexInputSection
                    }
                    .frame(maxWidth: .infinity)
                    
                    // Color Information
                    VStack(spacing: 15) {
                        colorInfoSection
                    }
                    .frame(maxWidth: .infinity)
                    
                    // Action buttons
                    VStack(spacing: 15) {
                        Text("Actions")
                            .font(.headline)
                        
                        actionButtonsSection
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 15)
                
                // Sliders layout - fill full width
                HStack(alignment: .top, spacing: 20) {
                    // RGB Sliders
                    rgbSlidersSection
                        .frame(maxWidth: .infinity)
                    
                    // HSL Sliders  
                    hslSlidersSection
                        .frame(maxWidth: .infinity)
                    
                    // LAB Sliders
                    labSlidersSection
                        .frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 15)
                
                // Saved Colors Section
                VStack(spacing: 15) {
                    saveButtonSection
                        .frame(maxWidth: 400)
                    presetColorsSection
                }
                .padding(.horizontal, 15)
            }
            .padding(.vertical, 15)
        }
    }
    
    @ViewBuilder
    var colorInfoSection: some View {
        let colorInfo = colorModel.createColorInfo(from: convertedColor)
        
        VStack(alignment: .leading, spacing: 8) {
            Text("Color Information")
                .font(.headline)
                .padding(.bottom, 5)
            
            ColorDetailRow(title: "Name", value: colorInfo.name)
            ColorDetailRow(title: "Hex", value: colorInfo.hex)
                .onTapGesture {
                    copyHexToClipboard(colorInfo.hex)
                }
            ColorDetailRow(title: "RGB", value: "rgb(\(colorInfo.rgb.red), \(colorInfo.rgb.green), \(colorInfo.rgb.blue))")
            ColorDetailRow(title: "HSL", value: "hsl(\(Int(hslHue)), \(Int(hslSaturation * 100))%, \(Int(hslLightness * 100))%)")
            ColorDetailRow(title: "LAB", value: "lab(\(Int(colorInfo.lab.l)), \(Int(colorInfo.lab.a)), \(Int(colorInfo.lab.b)))")
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(12)
    }
    
    // Copy hex code to clipboard with feedback
    private func copyHexToClipboard(_ hexCode: String) {
        UIPasteboard.general.string = hexCode
        copyFeedbackMessage = "Copied \(hexCode) to clipboard!"
        showingCopyAlert = true
        
        // Auto-dismiss after 2 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            showingCopyAlert = false
        }
    }
    
    @ViewBuilder
    var presetColorsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Saved Colors")
                    .font(.headline)
                Spacer()
                Text("\(colorModel.colorLibrary.count)")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            if colorModel.colorLibrary.isEmpty {
                // Empty state
                VStack(spacing: 8) {
                    Text("No saved colors yet")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("Save colors to see them here")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .frame(height: 60)
                .frame(maxWidth: .infinity)
                .background(Color(.systemGray6))
                .cornerRadius(12)
            } else {
                let columnCount = isLandscapeLayout ? 6 : (isRegularLayout ? 8 : 6)
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: columnCount), spacing: 8) {
                    ForEach(Array(colorModel.colorLibrary.enumerated()), id: \.element.id) { index, libraryColor in
                        Circle()
                            .fill(libraryColor.color)
                            .frame(width: isFullyExpandedLayout ? 40 : 44, height: isFullyExpandedLayout ? 40 : 44)
                            .overlay(
                                Circle()
                                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                            )
                            .shadow(radius: 2)
                            .onTapGesture {
                                selectPresetColor(libraryColor.color)
                            }
                            .onLongPressGesture {
                                // Long press to copy hex code
                                UIPasteboard.general.string = libraryColor.hex
                            }
                    }
                }
            }
        }
    }
    
    @ViewBuilder
    var saveButtonSection: some View {
        VStack(spacing: 12) {
            Button(action: {
                // Auto-generate name based on hex code or color name
                let colorInfo = colorModel.createColorInfo(from: convertedColor)
                let autoName = "\(colorInfo.name) (\(colorInfo.hex.uppercased()))"
                colorModel.saveColorToLibrary(convertedColor, name: autoName)
                showingLibrarySuccessAlert = true
            }) {
                HStack {
                    Image(systemName: "bookmark.fill")
                    Text("Save to Library")
                }
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(LinearGradient(
                    gradient: Gradient(colors: [convertedColor.opacity(0.8), convertedColor]),
                    startPoint: .leading,
                    endPoint: .trailing
                ))
                .cornerRadius(12)
            }
        }
    }
    
    private func selectPresetColor(_ color: Color) {
        convertedColor = color
        colorModel.selectedColor = color
        updateFromColor()
    }

    private var colorDisplaySection: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(convertedColor)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
            )
            .shadow(radius: 5)
    }
    
    private var hexInputSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Hex Color")
                .font(.headline)
            
            HStack {
                TextField("Enter hex color (e.g., #FF5733)", text: $hexInput)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .autocapitalization(.allCharacters)
                    .onChange(of: hexInput) { _, newValue in
                        convertFromHex(newValue)
                    }
                
                Button("Convert") {
                    convertFromHex(hexInput)
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(12)
    }
    
    private var rgbSlidersSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("RGB Values")
                .font(.headline)
            
            VStack(spacing: 10) {
                SliderRow(title: "Red", value: $rgbRed, range: 0...255) {
                    convertFromRGB()
                }
                SliderRow(title: "Green", value: $rgbGreen, range: 0...255) {
                    convertFromRGB()
                }
                SliderRow(title: "Blue", value: $rgbBlue, range: 0...255) {
                    convertFromRGB()
                }
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(12)
    }
    
    private var hslSlidersSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("HSL Values")
                .font(.headline)
            
            VStack(spacing: 10) {
                SliderRow(title: "Hue", value: $hslHue, range: 0...360, unit: "°") {
                    convertFromHSL()
                }
                SliderRow(title: "Saturation", value: $hslSaturation, range: 0...100, unit: "%") {
                    convertFromHSL()
                }
                SliderRow(title: "Lightness", value: $hslLightness, range: 0...100, unit: "%") {
                    convertFromHSL()
                }
            }
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(12)
    }
    
    private var labSlidersSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("LAB Values")
                .font(.headline)
            
            VStack(spacing: 10) {
                SliderRow(title: "L*", value: $labL, range: 0...100) {
                    convertFromLAB()
                }
                SliderRow(title: "a*", value: $labA, range: -128...127) {
                    convertFromLAB()
                }
                SliderRow(title: "b*", value: $labB, range: -128...127) {
                    convertFromLAB()
                }
            }
        }
        .padding()
        .background(Color.green.opacity(0.1))
        .cornerRadius(12)
    }
    
    private var actionButtonsSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Converted Values")
                .font(.headline)
            
            VStack(alignment: .leading, spacing: 5) {
                Text("RGB: (\(Int(rgbRed)), \(Int(rgbGreen)), \(Int(rgbBlue)))")
                    .font(.body.monospaced())
                
                Text("HSL: (\(Int(hslHue * 360))°, \(Int(hslSaturation * 100))%, \(Int(hslLightness * 100))%)")
                    .font(.body.monospaced())
                
                Text("LAB: (\(Int(labL)), \(Int(labA)), \(Int(labB)))")
                    .font(.body.monospaced())
                
                Text("Hex: \(hexInput)")
                    .font(.body.monospaced())
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
        }
    }
    
    private func convertFromHex(_ hex: String) {
        let cleanedHex = hex.replacingOccurrences(of: "#", with: "")
        
        guard cleanedHex.count == 6,
              let hexValue = Int(cleanedHex, radix: 16) else {
            return
        }
        
        let red = Double((hexValue >> 16) & 0xFF)
        let green = Double((hexValue >> 8) & 0xFF)
        let blue = Double(hexValue & 0xFF)
        
        rgbRed = red
        rgbGreen = green
        rgbBlue = blue
        
        convertedColor = Color(red: red / 255.0, green: green / 255.0, blue: blue / 255.0)
        updateHSLFromRGB()
        updateLABFromRGB()
    }
    
    private func convertFromRGB() {
        convertedColor = Color(red: rgbRed / 255.0, green: rgbGreen / 255.0, blue: rgbBlue / 255.0)
        
        // Update hex
        let hexValue = String(format: "#%02X%02X%02X", Int(rgbRed), Int(rgbGreen), Int(rgbBlue))
        hexInput = hexValue
        
        updateHSLFromRGB()
        updateLABFromRGB()
    }
    
    private func convertFromHSL() {
        let rgb = hslToRGB(h: hslHue / 360.0, s: hslSaturation / 100.0, l: hslLightness / 100.0)
        
        rgbRed = Double(rgb.0)
        rgbGreen = Double(rgb.1)
        rgbBlue = Double(rgb.2)
        
        convertedColor = Color(red: Double(rgb.0) / 255.0, green: Double(rgb.1) / 255.0, blue: Double(rgb.2) / 255.0)
        
        // Update hex
        let hexValue = String(format: "#%02X%02X%02X", rgb.0, rgb.1, rgb.2)
        hexInput = hexValue
        
        updateLABFromRGB()
    }
    
    private func convertFromLAB() {
        let lab = ColorModel.ColorInfo.LAB(l: labL, a: labA, b: labB)
        let color = colorModel.labToColor(lab: lab) // Use the new accurate LAB conversion
        convertedColor = color
        
        // Extract RGB components from the color
        let colorInfo = colorModel.createColorInfo(from: color)
        rgbRed = Double(colorInfo.rgb.red)
        rgbGreen = Double(colorInfo.rgb.green)
        rgbBlue = Double(colorInfo.rgb.blue)
        
        // Update hex
        let hexValue = String(format: "#%02X%02X%02X", colorInfo.rgb.red, colorInfo.rgb.green, colorInfo.rgb.blue)
        hexInput = hexValue
        
        // Update HSL
        hslHue = colorInfo.hsl.hue
        hslSaturation = colorInfo.hsl.saturation
        hslLightness = colorInfo.hsl.lightness
        
        colorModel.selectedColor = color
    }
    
    private func updateHSLFromRGB() {
        let r = rgbRed / 255.0
        let g = rgbGreen / 255.0
        let b = rgbBlue / 255.0
        
        let max = Swift.max(r, g, b)
        let min = Swift.min(r, g, b)
        let diff = max - min
        
        var h: Double = 0
        let s: Double
        let l: Double = (max + min) / 2
        
        if diff == 0 {
            s = 0
        } else {
            s = l > 0.5 ? diff / (2 - max - min) : diff / (max + min)
            
            switch max {
            case r:
                h = (g - b) / diff + (g < b ? 6 : 0)
            case g:
                h = (b - r) / diff + 2
            case b:
                h = (r - g) / diff + 4
            default:
                break
            }
            h /= 6
        }
        
        hslHue = h * 360
        hslSaturation = s * 100
        hslLightness = l * 100
    }
    
    private func updateLABFromRGB() {
        let rgb = ColorModel.ColorInfo.RGB(
            red: Int(rgbRed),
            green: Int(rgbGreen),
            blue: Int(rgbBlue)
        )
        
        let colorInfo = colorModel.createColorInfo(from: convertedColor)
        
        labL = colorInfo.lab.l
        labA = colorInfo.lab.a
        labB = colorInfo.lab.b
    }
    
    private func hslToRGB(h: Double, s: Double, l: Double) -> (Int, Int, Int) {
        let c = (1 - abs(2 * l - 1)) * s
        let x = c * (1 - abs((h * 6).truncatingRemainder(dividingBy: 2) - 1))
        let m = l - c / 2
        
        var r: Double = 0
        var g: Double = 0
        var b: Double = 0
        
        let hue = h * 6
        
        if hue < 1 {
            r = c; g = x; b = 0
        } else if hue < 2 {
            r = x; g = c; b = 0
        } else if hue < 3 {
            r = 0; g = c; b = x
        } else if hue < 4 {
            r = 0; g = x; b = c
        } else if hue < 5 {
            r = x; g = 0; b = c
        } else {
            r = c; g = 0; b = x
        }
        
        return (Int((r + m) * 255), Int((g + m) * 255), Int((b + m) * 255))
    }
    
    private func updateFromColor() {
        updateInputsFromColor(colorModel.selectedColor)
    }
    
    private func updateInputsFromColor(_ color: Color) {
        let colorInfo = colorModel.createColorInfo(from: color)
        
        hexInput = colorInfo.hex
        rgbRed = Double(colorInfo.rgb.red)
        rgbGreen = Double(colorInfo.rgb.green)
        rgbBlue = Double(colorInfo.rgb.blue)
        hslHue = colorInfo.hsl.hue
        hslSaturation = colorInfo.hsl.saturation
        hslLightness = colorInfo.hsl.lightness
        labL = colorInfo.lab.l
        labA = colorInfo.lab.a
        labB = colorInfo.lab.b
        
        convertedColor = color
    }
}

struct ColorDetailRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text("\(title):")
                .font(.subheadline)
                .fontWeight(.medium)
                .frame(width: 50, alignment: .leading)
            
            Text(value)
                .font(.subheadline.monospaced())
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            Button(action: {
                UIPasteboard.general.string = value
            }) {
                Image(systemName: "doc.on.doc")
                    .foregroundColor(.blue)
                    .font(.caption)
            }
        }
    }
}

struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String
    let onChange: () -> Void
    
    init(title: String, value: Binding<Double>, range: ClosedRange<Double>, unit: String = "", onChange: @escaping () -> Void) {
        self.title = title
        self._value = value
        self.range = range
        self.unit = unit
        self.onChange = onChange
    }
    
    var body: some View {
        HStack {
            Text(title)
                .frame(width: 80, alignment: .leading)
            
            Slider(value: $value, in: range) { _ in
                onChange()
            }
            
            Text("\(Int(value))\(unit)")
                .frame(width: 50, alignment: .trailing)
                .font(.body.monospaced())
        }
    }
}

struct OutputRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title + ":")
                .font(.headline)
                .frame(width: 100, alignment: .leading)
            
            Text(value)
                .font(.body.monospaced())
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
            
            Button(action: {
                UIPasteboard.general.string = value
            }) {
                Image(systemName: "doc.on.doc")
                    .foregroundColor(.blue)
            }
        }
    }
}

