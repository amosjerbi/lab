//
//  ColorSelectorTests.swift
//  ColorSelectorTests
//
//  Created by Amos Jerbi on 29/07/2025.
//

import Testing
@testable import ColorSelector

struct ColorSelectorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
